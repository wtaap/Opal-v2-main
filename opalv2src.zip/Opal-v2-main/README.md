# Opal v2
Buildable and functionable Opal v2, btw u need jdk 21 
**hi**
Pro hecker🔥🔥🔥
