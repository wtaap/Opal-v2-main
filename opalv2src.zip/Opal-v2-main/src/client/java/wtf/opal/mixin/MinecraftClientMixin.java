package wtf.opal.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wtf.opal.client.OpalClient;
import wtf.opal.client.feature.helper.impl.player.mouse.MouseButton;
import wtf.opal.client.feature.helper.impl.player.mouse.MouseHelper;
import wtf.opal.client.feature.helper.impl.player.slot.SlotHelper;
import wtf.opal.client.feature.module.impl.combat.BlockModule;
import wtf.opal.client.feature.module.impl.movement.InventoryMoveModule;
import wtf.opal.client.feature.module.impl.visual.AnimationsModule;
import wtf.opal.duck.ClientPlayerEntityAccess;
import wtf.opal.event.EventDispatcher;
import wtf.opal.event.impl.game.JoinWorldEvent;
import wtf.opal.event.impl.game.PostGameTickEvent;
import wtf.opal.event.impl.game.PreGameTickEvent;
import wtf.opal.event.impl.game.ScheduledExecutablesEvent;
import wtf.opal.event.impl.game.input.MouseHandleInputEvent;
import wtf.opal.event.impl.game.input.PostHandleInputEvent;
import wtf.opal.event.impl.game.player.interaction.AttackDelayEvent;
import wtf.opal.event.impl.game.player.interaction.ItemUseEvent;
import wtf.opal.event.impl.game.player.interaction.block.BlockPlacedEvent;
import wtf.opal.event.impl.game.server.ServerDisconnectEvent;
import wtf.opal.event.impl.render.ResolutionChangeEvent;
import wtf.opal.utility.player.PlayerUtility;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    @Shadow
    protected abstract boolean doAttack();

    @Shadow
    protected int attackCooldown;

    @Shadow
    @Nullable
    public HitResult crosshairTarget;

    @Shadow
    @Nullable
    public ClientPlayerEntity player;

    private MinecraftClientMixin() {
    }

    @Inject(
            method = "<init>",
            at = @At("TAIL")
    )
    private void postInitialization(final RunArgs args, final CallbackInfo ci) {
        OpalClient.getInstance().runPostInitializations();
    }

    @Inject(
            method = "handleInputEvents",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z", ordinal = 0)
    )
    private void handleInputEventsMouse(final CallbackInfo info) {
        EventDispatcher.dispatch(new MouseHandleInputEvent());
    }

    @Inject(
            method = "handleInputEvents",
            at = @At("TAIL")
    )
    private void handleInputEventsTail(final CallbackInfo ci) {
        MouseHelper.getInstance().tick();

        EventDispatcher.dispatch(new PostHandleInputEvent());
    }

    @Redirect(
            method = "doAttack",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;swingHand(Lnet/minecraft/util/Hand;)V")
    )
    private void redirectAttackSwings(ClientPlayerEntity instance, Hand hand) {
        final MouseButton leftButton = MouseHelper.getLeftButton();
        if (leftButton.isShowSwings()) {
            instance.swingHand(hand);
        } else {
            ((ClientPlayerEntityAccess) instance).opal$swingHandServerside(hand);
        }
    }

    @Redirect(
            method = "doItemUse",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;swingHand(Lnet/minecraft/util/Hand;)V")
    )
    private void redirectUseSwings(ClientPlayerEntity instance, Hand hand) {
        final MouseButton rightButton = MouseHelper.getRightButton();
        if (rightButton.isShowSwings()) {
            instance.swingHand(hand);
        } else {
            ((ClientPlayerEntityAccess) instance).opal$swingHandServerside(hand);
        }
    }

    @Inject(
            method = "setScreen",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;unpressAll()V", shift = At.Shift.AFTER)
    )
    private void hookSetScreen(Screen screen, CallbackInfo ci) {
        if (OpalClient.getInstance().isPostInitialization()) {
            final InventoryMoveModule inventoryMove = OpalClient.getInstance().getModuleRepository().getModule(InventoryMoveModule.class);
            if (inventoryMove.isEnabled() && !inventoryMove.isBlocked()) {
                PlayerUtility.updateMovementKeyStates();
            }
        }
    }

    @Redirect(
            method = "handleInputEvents",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;setSelectedSlot(I)V")
    )
    private void redirectSelectedSlot(PlayerInventory instance, int value) {
        SlotHelper slotHelper = SlotHelper.getInstance();
        if (slotHelper.isActive()) {
            if (slotHelper.getSilence() != SlotHelper.Silence.NONE) {
                slotHelper.setVisualSlot(value);
            }
        } else {
            instance.setSelectedSlot(value);
        }
    }

    @Inject(
            method = "handleInputEvents",
            at = @At(value = "FIELD", target = "Lnet/minecraft/client/option/GameOptions;socialInteractionsKey:Lnet/minecraft/client/option/KeyBinding;", shift = At.Shift.BEFORE)
    )
    private void postSlotHandleInput(CallbackInfo ci) {
        SlotHelper.getInstance().sync(false, false);
    }

    @Redirect(
            method = "handleInputEvents",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;isPressed()Z")
    )
    private boolean redirectIsPressed(KeyBinding instance) {
        final MouseButton mouseButton = MouseHelper.getButtonFromBinding(instance);
        if (mouseButton != null) {
            return mouseButton.isPressed();
        }
        return instance.isPressed();
    }

    @Redirect(
            method = "handleInputEvents",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;wasPressed()Z"),
            slice = @Slice(
                    from = @At(value = "FIELD", target = "Lnet/minecraft/client/option/GameOptions;useKey:Lnet/minecraft/client/option/KeyBinding;", ordinal = 1),
                    to = @At("TAIL")
            )
    )
    private boolean redirectWasPressed(KeyBinding instance) {
        final MouseButton mouseButton = MouseHelper.getButtonFromBinding(instance);
        if (mouseButton != null) {
            return mouseButton.wasPressed();
        }
        return instance.wasPressed();
    }

    @Redirect(
            method = "handleInputEvents",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;wasPressed()Z", ordinal = 11)
    )
    private boolean redirectUsingAttack(KeyBinding instance, @Local LocalBooleanRef bl3) {
        if (this.isSwingWhileUsing() && MouseHelper.getLeftButton().wasPressed()) {
            final boolean currentValue = bl3.get();
            final boolean newValue = currentValue | doAttack();
            bl3.set(newValue);
            return true;
        }
        return false;
    }

    @Inject(
            method = "doItemUse",
            at = @At("HEAD")
    )
    private void hookItemUse(CallbackInfo ci) {
        EventDispatcher.dispatch(new ItemUseEvent());
    }

    @Inject(
            method = "handleInputEvents",
            at = @At(value = "FIELD", target = "Lnet/minecraft/client/option/GameOptions;useKey:Lnet/minecraft/client/option/KeyBinding;", ordinal = 1)
    )
    private void onItemUseMouseHandle(CallbackInfo ci) {
        final AnimationsModule animationsModule = OpalClient.getInstance().getModuleRepository().getModule(AnimationsModule.class);
        final MouseButton leftButton = MouseHelper.getLeftButton();
        if (animationsModule.isEnabled() && animationsModule.isSwingWhileUsing() && leftButton.isPressed() && leftButton.isShowSwings()) {
            if ((this.crosshairTarget != null && this.crosshairTarget.getType() == HitResult.Type.BLOCK) || leftButton.wasPressed()) {
                ((ClientPlayerEntityAccess) this.player).opal$swingHandClientside(Hand.MAIN_HAND);
            }
        }

        //noinspection StatementWithEmptyBody
        while (leftButton.wasPressed()) ;
    }

    @Unique
    private boolean isSwingWhileUsing() {
        final BlockModule blockModule = OpalClient.getInstance().getModuleRepository().getModule(BlockModule.class);
        return blockModule.isEnabled() && blockModule.isSwingAllowed();
    }

    @Redirect(
            method = "doAttack",
            at = @At(value = "FIELD", target = "Lnet/minecraft/client/MinecraftClient;attackCooldown:I", opcode = Opcodes.PUTFIELD)
    )
    private void onAttackCooldown(MinecraftClient instance, int value) {
        final AttackDelayEvent event = new AttackDelayEvent(value);
        EventDispatcher.dispatch(event);
        this.attackCooldown = event.getDelay();
    }

    @Inject(
            method = "render",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;runTasks()V", shift = At.Shift.BEFORE)
    )
    private void onGameLoop(boolean tick, CallbackInfo ci, @Local(ordinal = 0) int ticks) {
        EventDispatcher.dispatch(new ScheduledExecutablesEvent(ticks > 0));
    }

    @Inject(
            method = "tick",
            at = @At("HEAD")
    )
    private void tickHead(final CallbackInfo info) {
        EventDispatcher.dispatch(new PreGameTickEvent());
    }

    @Inject(
            method = "joinWorld",
            at = @At("HEAD")
    )
    private void hookJoinWorld(ClientWorld world, CallbackInfo ci) {
        EventDispatcher.dispatch(new JoinWorldEvent());
    }

    @Inject(
            method = "tick",
            at = @At("TAIL")
    )
    private void tickTail(final CallbackInfo info) {
        EventDispatcher.dispatch(new PostGameTickEvent());
    }

    @Inject(
            method = "onDisconnected",
            at = @At("HEAD")
    )
    private void disconnected(final CallbackInfo ci) {
        EventDispatcher.dispatch(new ServerDisconnectEvent());
    }

    @Inject(
            method = "isTelemetryEnabledByApi",
            at = @At("HEAD"),
            cancellable = true
    )
    private void disableTelemetry(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }

    @Inject(
            method = "onResolutionChanged",
            at = @At("HEAD")
    )
    private void resolutionChange(CallbackInfo ci) {
        EventDispatcher.dispatch(new ResolutionChangeEvent());
    }

    @Inject(
            method = "doItemUse",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/ActionResult$Success;swingSource()Lnet/minecraft/util/ActionResult$SwingSource;", ordinal = 1)
    )
    private void hookBlockPlaceEvent(CallbackInfo ci, @Local BlockHitResult blockHitResult) {
        EventDispatcher.dispatch(new BlockPlacedEvent(blockHitResult));
    }

    @Redirect(
            method = "doItemUse",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;resetEquipProgress(Lnet/minecraft/util/Hand;)V", ordinal = 0)
    )
    private void redirectResetEquipProgress(HeldItemRenderer instance, Hand hand) {
        // prevent equip progress reset if placing a block but the visual item is not a block
        SlotHelper slotHelper = SlotHelper.getInstance();
        if (hand == Hand.MAIN_HAND && slotHelper.isActive() && !(slotHelper.getMainHandStack(player).getItem() instanceof BlockItem)) {
            return;
        }
        instance.resetEquipProgress(hand);
    }

}
