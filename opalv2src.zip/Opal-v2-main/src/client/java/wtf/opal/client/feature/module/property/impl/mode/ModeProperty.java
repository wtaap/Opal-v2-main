package wtf.opal.client.feature.module.property.impl.mode;

import wtf.opal.client.feature.module.Module;
import wtf.opal.client.feature.module.property.Property;
import wtf.opal.client.screen.click.dropdown.panel.property.PropertyPanel;
import wtf.opal.client.screen.click.dropdown.panel.property.impl.ModePropertyComponent;

public final class ModeProperty<T extends Enum<T>> extends Property<T> {

    private final T[] values;
    private Module module;

    private boolean theme;

    public ModeProperty(final String name, final T value) {
        super(name);
        setValue(value);
        this.values = getEnumConstants();
    }

    public ModeProperty(final String name, final T value, final T[] values) {
        super(name);
        setValue(value);
        this.values = values;
    }

    public ModeProperty(final String name, final T value, final boolean theme) {
        super(name);
        setValue(value);
        this.values = getEnumConstants();

        this.theme = theme;
    }

    public ModeProperty(final String name, final ModuleMode<?> parent, final T value) {
        super(name, parent);
        setValue(value);
        this.values = getEnumConstants();
    }

    public ModeProperty(final String name, final Module module, final T value) {
        super(name);
        setValue(value);
        this.values = getEnumConstants();
        this.module = module;
        module.setModeProperty(this);
    }

    @SuppressWarnings("unchecked")
    private T[] getEnumConstants() {
        return (T[]) getValue().getClass().getEnumConstants();
    }

    public T[] getValues() {
        return values;
    }

    public void setValueOrdinal(final int value) {
        if (module != null && module.isEnabled()) {
            module.getModuleModes().forEach(ModuleMode::onDisable);
        }
        setValue(values[value]);
        if (module != null) {
            for (final ModuleMode<?> mode : module.getModuleModes()) {
                if (mode.getEnumValue().ordinal() == value && module.isEnabled()) {
                    mode.onEnable();
                    break;
                }
            }
        }
    }

    public void cycle(final boolean forwards) {
        final int currentIndex = getValue().ordinal();
        final int nextIndex = (currentIndex + (forwards ? 1 : values.length - 1)) % values.length;
        setValueOrdinal(nextIndex);
    }

    public boolean isTheme() {
        return theme;
    }

    public boolean is(final T value) {
        return getValue() == value;
    }

    @Override
    public PropertyPanel<?> createClickGUIComponent() {
        return new ModePropertyComponent(this);
    }

    @Override
    public void applyValue(Object propertyValue) {
        if (propertyValue instanceof String valueString) {
            for (T possibleValue : values) {
                if (possibleValue.name().equals(valueString)) {
                    setValueOrdinal(possibleValue.ordinal());
                    break;
                }
            }
        }
    }
}
